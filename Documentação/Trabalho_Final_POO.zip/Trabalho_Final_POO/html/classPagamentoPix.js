var classPagamentoPix =
[
    [ "getForma", "classPagamentoPix.html#a82eda3e9d64f9bd922a84540d23f86ad", null ],
    [ "processarPagamento", "classPagamentoPix.html#a5497ef80c04a9a766480484906ad9af1", null ]
];