var classProduto =
[
    [ "Produto", "classProduto.html#aa4113a46de74fbdd0e47f3eeac0d4af5", null ],
    [ "adicionarEstoque", "classProduto.html#aee0c36b5e336820101d0a54878d38a68", null ],
    [ "alterarPreco", "classProduto.html#a9fc46c4a33fbf6fd1e744292b99a5577", null ],
    [ "getCodigo", "classProduto.html#a4b97c2cbb353a3367609391ba7e26ef8", null ],
    [ "getNome", "classProduto.html#a7a21bb535ffcf7c9d16e2cc6d7d4fffe", null ],
    [ "getPreco", "classProduto.html#ac9aa11b811599609795d251a403f28f3", null ],
    [ "getQuantidade", "classProduto.html#aeb61bc3dfc15ef4db5b09051ffd0aa44", null ],
    [ "retirarEstoque", "classProduto.html#aa13d9d6662a3dd31db6ba248f767bded", null ],
    [ "codigo", "classProduto.html#ae6d3ea5fbacb6a6d55e29111bc045465", null ],
    [ "nome", "classProduto.html#a15677dead9a1b79b110808786ea45c07", null ],
    [ "preco", "classProduto.html#ae483b336e7d93372fe61585f72f0be42", null ],
    [ "quantidade", "classProduto.html#afa69804a3b0165a97ca8256a08d1a4ef", null ]
];