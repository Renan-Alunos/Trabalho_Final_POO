var hierarchy =
[
    [ "Catalogo", "classCatalogo.html", null ],
    [ "EstrategiaPagamento", "interfaceEstrategiaPagamento.html", [
      [ "PagamentoCartao", "classPagamentoCartao.html", null ],
      [ "PagamentoPix", "classPagamentoPix.html", null ]
    ] ],
    [ "EventoSistema", "enumEventoSistema.html", null ],
    [ "IllegalArgumentException", null, [
      [ "CpfJaCadastradoException", "classCpfJaCadastradoException.html", null ]
    ] ],
    [ "ItemPedido", "classItemPedido.html", null ],
    [ "JFrame", null, [
      [ "TelaFarmacia", "classTelaFarmacia.html", null ],
      [ "TelaFuncionario", "classTelaFuncionario.html", null ]
    ] ],
    [ "JPanel", null, [
      [ "TelaCliente", "classTelaCliente.html", null ]
    ] ],
    [ "Main", "classMain.html", null ],
    [ "ObservadorSistema", "interfaceObservadorSistema.html", [
      [ "AlertasEstoque", "classAlertasEstoque.html", null ],
      [ "PersistenciaCatalogo", "classPersistenciaCatalogo.html", null ]
    ] ],
    [ "Pagamento", "classPagamento.html", null ],
    [ "Pedido", "classPedido.html", null ],
    [ "Produto", "classProduto.html", null ],
    [ "Sistema", "classSistema.html", null ],
    [ "Usuario", "classUsuario.html", [
      [ "Cliente", "classCliente.html", null ],
      [ "Funcionario", "classFuncionario.html", null ]
    ] ]
];