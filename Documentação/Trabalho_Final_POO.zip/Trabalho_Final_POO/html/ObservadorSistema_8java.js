var ObservadorSistema_8java =
[
    [ "ObservadorSistema", "interfaceObservadorSistema.html", "interfaceObservadorSistema" ]
];