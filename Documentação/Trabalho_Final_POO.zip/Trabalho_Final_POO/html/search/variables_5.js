var searchData=
[
  ['limite_0',['limite',['../classAlertasEstoque.html#adc3203031616065b573b85e5a2b22a1f',1,'AlertasEstoque']]],
  ['limite_5festoque_5fbaixo_1',['LIMITE_ESTOQUE_BAIXO',['../classSistema.html#a514a0dbe4252138cecda5df3ec67a31c',1,'Sistema']]],
  ['limite_5fprodutos_2',['LIMITE_PRODUTOS',['../classCatalogo.html#a72390571ef35b1c7039f945a8ad8ca11',1,'Catalogo']]]
];
