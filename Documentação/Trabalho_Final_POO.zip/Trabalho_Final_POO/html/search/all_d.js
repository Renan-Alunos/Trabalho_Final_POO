var searchData=
[
  ['quantidade_0',['quantidade',['../classItemPedido.html#af20ff6db5f086aff8e5570c53324af59',1,'ItemPedido.quantidade'],['../classProduto.html#afa69804a3b0165a97ca8256a08d1a4ef',1,'Produto.quantidade']]]
];
