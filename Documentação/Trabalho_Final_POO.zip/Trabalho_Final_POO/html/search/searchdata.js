var indexSectionsWithContent =
{
  0: "abcdefgilmnopqrstuv",
  1: "acefimopstu",
  2: "acefimopstu",
  3: "abcdefgilmnprstuv",
  4: "acefilmnopqrstuv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Arquivos",
  3: "Funções",
  4: "Variáveis"
};

