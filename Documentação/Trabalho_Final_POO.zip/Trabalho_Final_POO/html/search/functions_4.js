var searchData=
[
  ['exigirpedido_0',['exigirPedido',['../classMain.html#a814112b3d7b1882da8b060d4a5790d7b',1,'Main']]]
];
