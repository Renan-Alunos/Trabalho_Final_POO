var searchData=
[
  ['nome_0',['nome',['../classProduto.html#a15677dead9a1b79b110808786ea45c07',1,'Produto.nome'],['../classUsuario.html#a391e6dab43041a112b666602c823c66c',1,'Usuario.nome']]],
  ['numero_1',['numero',['../classPedido.html#a31cb58e37025dfc08ab705c48c7b3933',1,'Pedido']]]
];
