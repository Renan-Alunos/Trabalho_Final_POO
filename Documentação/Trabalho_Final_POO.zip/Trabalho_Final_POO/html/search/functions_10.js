var searchData=
[
  ['voltaraologin_0',['voltarAoLogin',['../classTelaFarmacia.html#addd6a192c7e4f320caab2adbb892ffcf',1,'TelaFarmacia']]]
];
