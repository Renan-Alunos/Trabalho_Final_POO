var searchData=
[
  ['usuario_0',['Usuario',['../classUsuario.html#a85a758a5744edfe2ec376a3e0d6cbb2a',1,'Usuario']]]
];
