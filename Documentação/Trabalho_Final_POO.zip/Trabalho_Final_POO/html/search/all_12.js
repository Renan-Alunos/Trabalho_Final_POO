var searchData=
[
  ['valortotal_0',['valorTotal',['../classTelaCliente.html#a97e9e8b0937a16ac23f26d00d099dac6',1,'TelaCliente']]],
  ['versao_1',['VERSAO',['../classCatalogo.html#abfaa1bc1682d91c9d86e26701f82f6db',1,'Catalogo']]],
  ['voltaraologin_2',['voltarAoLogin',['../classTelaFarmacia.html#addd6a192c7e4f320caab2adbb892ffcf',1,'TelaFarmacia']]]
];
