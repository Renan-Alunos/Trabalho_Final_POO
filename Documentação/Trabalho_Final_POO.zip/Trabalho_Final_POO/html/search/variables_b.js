var searchData=
[
  ['resumocarrinho_0',['resumoCarrinho',['../classTelaCliente.html#a372430eba76a376d2b3d641b14df33a8',1,'TelaCliente']]]
];
