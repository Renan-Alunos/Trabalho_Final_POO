var interfaceEstrategiaPagamento =
[
    [ "getForma", "interfaceEstrategiaPagamento.html#a6fca2db358a082812cc888328cfd4847", null ],
    [ "processarPagamento", "interfaceEstrategiaPagamento.html#a88ec55a406a189739cb4f29ff27d467e", null ]
];