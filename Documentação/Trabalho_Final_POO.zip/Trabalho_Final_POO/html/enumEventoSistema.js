var enumEventoSistema =
[
    [ "ESTOQUE_BAIXO", "enumEventoSistema.html#ac1c3083ec168c0339d9a71d6c33f8295", null ],
    [ "ESTOQUE_REPOSTO", "enumEventoSistema.html#a53621b62e6d6882b5d5a326ccc35040f", null ],
    [ "PEDIDO_FINALIZADO", "enumEventoSistema.html#a8da4ef4019ff5e5f16246682f656b6a2", null ],
    [ "PRECO_ALTERADO", "enumEventoSistema.html#aef75ed42c16321ab0a5d15b6e7851dfe", null ],
    [ "PRODUTO_CADASTRADO", "enumEventoSistema.html#ad8692cca2d3729e922961166358f5116", null ]
];