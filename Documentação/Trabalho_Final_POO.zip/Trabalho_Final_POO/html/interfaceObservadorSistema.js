var interfaceObservadorSistema =
[
    [ "atualizar", "interfaceObservadorSistema.html#a2efdb6eeeaa1dd7d5ebc900b936aaa72", null ]
];