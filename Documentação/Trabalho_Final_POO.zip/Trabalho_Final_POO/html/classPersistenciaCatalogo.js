var classPersistenciaCatalogo =
[
    [ "PersistenciaCatalogo", "classPersistenciaCatalogo.html#ac4f247a247f04eb28fc895ae50131c77", null ],
    [ "atualizar", "classPersistenciaCatalogo.html#a1b4f02f8439ec3dadea9170df12057fb", null ],
    [ "catalogo", "classPersistenciaCatalogo.html#a4361e1fb5f5cbdd5dd8bec8a70373ea6", null ]
];