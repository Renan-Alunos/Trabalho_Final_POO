var classFuncionario =
[
    [ "Funcionario", "classFuncionario.html#aa597ea86f5d8a57c0b0f8d74e8c90c44", null ],
    [ "adicionarProduto", "classFuncionario.html#a88ae27638dc4d2427d85c9e2241abbd8", null ],
    [ "alterarPreco", "classFuncionario.html#a913248899e1c54783f0276951fa4bdd7", null ],
    [ "getMatricula", "classFuncionario.html#ad1348fbab772e3d70bb02611931119a7", null ],
    [ "getTipoUsuario", "classFuncionario.html#ad73b0efa888da7b82f8709035829ad28", null ],
    [ "matricula", "classFuncionario.html#ae736f505927609756d5c68b22dc24831", null ]
];