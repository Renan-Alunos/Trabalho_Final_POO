var classCatalogo =
[
    [ "Catalogo", "classCatalogo.html#af9705a6392a43e76880282561da522d3", null ],
    [ "adicionarProduto", "classCatalogo.html#ad14670e60f2f28faa0f12fc85e73c6cf", null ],
    [ "buscarProduto", "classCatalogo.html#a592752c0c5536e416f88957caf4ab2a1", null ],
    [ "carregar", "classCatalogo.html#a13a0c000d491a2ac7218530578787319", null ],
    [ "getProdutos", "classCatalogo.html#a449004534d5916ea3afd48714ec90b9c", null ],
    [ "guardarBackup", "classCatalogo.html#a07e30df4b1749ae400d1be4554b53a99", null ],
    [ "removerProduto", "classCatalogo.html#a5e02d78666e00938c2d11daed04cb46c", null ],
    [ "salvar", "classCatalogo.html#af59b33f9f782fb6123fec3ad8c12f25d", null ],
    [ "arquivo", "classCatalogo.html#a2b18da8a9c4e42f2f02dcd9a8fa39256", null ],
    [ "IDENTIFICADOR", "classCatalogo.html#ac99cc44e73d26fe77ffa9c70cb6386dd", null ],
    [ "LIMITE_PRODUTOS", "classCatalogo.html#a72390571ef35b1c7039f945a8ad8ca11", null ],
    [ "produtos", "classCatalogo.html#a089c9e00ac7328f1dfd9cece052575b2", null ],
    [ "VERSAO", "classCatalogo.html#abfaa1bc1682d91c9d86e26701f82f6db", null ]
];