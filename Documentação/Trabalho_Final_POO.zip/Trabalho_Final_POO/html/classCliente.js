var classCliente =
[
    [ "Cliente", "classCliente.html#a1255af1a27b360d92122cb91d968bdca", null ],
    [ "adicionarPedido", "classCliente.html#a59ca8edb1b3f5709eae836cf22cda091", null ],
    [ "getPedidos", "classCliente.html#a807f876ee79ed41d7d8e010efa8d6328", null ],
    [ "getTipoUsuario", "classCliente.html#a3dc2a0a4d8681c22c1597ec7edc1226b", null ],
    [ "pedidos", "classCliente.html#a35d86f0df85cbf93c29b095c9a3559fc", null ]
];