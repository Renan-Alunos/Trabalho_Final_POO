var classAlertasEstoque =
[
    [ "AlertasEstoque", "classAlertasEstoque.html#a4c8d770eb8b10b35a12f342f7ab8dbbf", null ],
    [ "atualizar", "classAlertasEstoque.html#aa66d8675373d18428d8b695a3704dc6e", null ],
    [ "montarMensagem", "classAlertasEstoque.html#a4c443273490913703a7c4f180a943198", null ],
    [ "retirarPendentes", "classAlertasEstoque.html#a0119475f8b1c310deba7c99742be99fd", null ],
    [ "limite", "classAlertasEstoque.html#adc3203031616065b573b85e5a2b22a1f", null ],
    [ "pendentes", "classAlertasEstoque.html#a70e846dd9bcfc0835341fef25a5acab3", null ]
];