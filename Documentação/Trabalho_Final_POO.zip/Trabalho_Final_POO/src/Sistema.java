import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
/*
  CADASTRAR CLIENTES, CADASTRAR PRODUTOS,
  REALIZAR PEDIDOS, GERAR RELATÓRIOS DE VENDAS, VER ESTOQUE
*/
public class Sistema{
    //armazena clientes e funcionários
    private ArrayList<Usuario> usuarios = new ArrayList<>();

    //catálogo
    private Catalogo catalogo = new Catalogo();
    private ArrayList<Pedido> pedidosAbertos = new ArrayList<>();
    private ArrayList<Pedido> pedidosFinalizados = new ArrayList<>();
    private int proximoNumeroPedido = 1;

    //Observer: quem quiser ser avisado das mudanças se registra aqui
    public static final int LIMITE_ESTOQUE_BAIXO = 3;
    private final ArrayList<ObservadorSistema> observadores = new ArrayList<>();
    private final AlertasEstoque alertasEstoque = new AlertasEstoque(LIMITE_ESTOQUE_BAIXO);

    public Sistema(){
        //funcionário administrador
        Funcionario administrador = new Funcionario("Administrador","00000000000","admin123","F01");
        usuarios.add(administrador);

        //carrega o catálogo salvo; se não existir (ou estiver danificado), usa os produtos iniciais
        if (!catalogo.carregar()) {
            catalogo.adicionarProduto(new Produto(1, "Dipirona 500mg", 12.50, 5));//(codigo, nome, preço, quantidade)
            catalogo.adicionarProduto(new Produto(2, "Paracetamol 750mg", 9.90, 10));
            catalogo.adicionarProduto(new Produto(3, "Ibuprofeno 400mg", 15.90, 6));
            catalogo.adicionarProduto(new Produto(4, "Vitamina C", 19.90, 5));
            catalogo.adicionarProduto(new Produto(5, "Soro Fisiológico", 7.50, 10));
            catalogo.salvar();
        }

        //observadores internos: salvar o catálogo e guardar os avisos de estoque baixo
        adicionarObservador(new PersistenciaCatalogo(catalogo));
        adicionarObservador(alertasEstoque);

        //produtos que já estão com estoque baixo ao iniciar também geram aviso
        for (Produto produto : catalogo.getProdutos()) {
            if (produto.getQuantidade() <= LIMITE_ESTOQUE_BAIXO) {
                notificar(EventoSistema.ESTOQUE_BAIXO, produto);
            }
        }
    }

    public void adicionarObservador(ObservadorSistema observador) {
        if (observador != null && !observadores.contains(observador)) {
            observadores.add(observador);
        }
    }

    public void removerObservador(ObservadorSistema observador) {
        observadores.remove(observador);
    }

    //avisa todos os observadores (percorre uma cópia, pois a lista pode mudar durante o aviso)
    private void notificar(EventoSistema evento, Object dados) {
        for (ObservadorSistema observador : new ArrayList<>(observadores)) {
            try {
                observador.atualizar(evento, dados);
            } catch (RuntimeException erro) {
                System.err.println("Erro em um observador: " + erro);
            }
        }
    }

    //devolve (e limpa) os avisos de estoque baixo ainda não vistos pelo funcionário
    public ArrayList<String> retirarAlertasEstoque() {
        return alertasEstoque.retirarPendentes();
    }

    //arredonda para centavos (evita preco com 3+ casas, ex.: 9,999)
    private double arredondar(double valor) {
        return BigDecimal.valueOf(valor).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }
    
    //login usuário
    public Usuario fazerLogin(String cpf, String senha){
        for (Usuario usuario : usuarios){
            if (usuario.getCpf().equals(cpf) && usuario.getSenha().equals(senha)){
                return usuario;
            }
        }
        return null; //retorna null se não encontrar o usuário
    }

    public Cliente cadastrarCliente(String nome, String cpf, String senha) {
        /*
            if (nome == null || nome.isBlank() || cpf == null || !cpf.matches("\\d{11}") || senha == null || senha.isBlank()) {
                throw new IllegalArgumentException("Dados invalidos!");
            }
        */
        if (nome == null || nome.isBlank()) {
            throw new IllegalArgumentException("O nome nao pode estar vazio!");
        }
        if (cpf == null || !cpf.matches("\\d{11}")) {
            throw new IllegalArgumentException("O CPF deve conter 11 numeros!");
        }
        if (senha == null || senha.isBlank()) {
            throw new IllegalArgumentException("A senha nao pode estar vazia!");
        }
        for (Usuario usuario : usuarios) {
            if (usuario.getCpf().equals(cpf)) {
                throw new CpfJaCadastradoException();
            }
        }
        Cliente cliente = new Cliente(nome, cpf, senha);
        usuarios.add(cliente);
        return cliente;
    }

    public String buscarClientes(String cpf){ //buscara usuário a partir de seu cpf
        for(Usuario usuario : usuarios){
            if (usuario instanceof Cliente && usuario.getCpf().equals(cpf)){
                return usuario.getNome();
            }
        }
        return null;
    }

    public ArrayList<Produto> listarProdutos(){
        return catalogo.getProdutos();
    }

    public boolean cadastrarProduto(Funcionario funcionario, int codigo, String nome, double preco, int quantidade){
        //verifica se o funcionário pertence ao sistema
        if (funcionario == null || !usuarios.contains(funcionario)){
            return false;
        }

        //verifica se os dados são válidos (o preço é arredondado para centavos antes de validar)
        if (!Double.isFinite(preco)){
            return false;
        }
        preco = arredondar(preco);
        if (codigo <= 0 || nome == null || nome.isBlank() || preco <= 0 || quantidade < 0){
            return false;
        }

        //verifica se o código já existe
        if (catalogo.buscarProduto(codigo) != null){
            return false;
        }

        //cria um produto
        Produto produto = new Produto(codigo, nome, preco, quantidade);

        //só o funcionário adiciona o produto ao catálogo
        funcionario.adicionarProduto(catalogo, produto);
        notificar(EventoSistema.PRODUTO_CADASTRADO, produto);

        return true;
    }

    public boolean alterarPreco(Funcionario funcionario, int codigo, double novoPreco) {
        //verifica se o funcionário está cadastrado
        if (funcionario == null || !usuarios.contains(funcionario)) {
            return false;
        }

        //verifica se o preço é válido (mesma regra do cadastro: maior que zero)
        if (!Double.isFinite(novoPreco)) {
            return false;
        }
        novoPreco = arredondar(novoPreco);
        if (novoPreco <= 0) {
            return false;
        }

        //busca produto por código
        Produto produto = catalogo.buscarProduto(codigo);

        //verifica se o produto existe
        if (produto == null) {
            return false;
        }

        //altera preço
        funcionario.alterarPreco(produto, novoPreco);
        notificar(EventoSistema.PRECO_ALTERADO, produto);

        return true;
    }

    public boolean reporEstoque(Funcionario funcionario, int codigo, int quantidade) {
        Produto produto = catalogo.buscarProduto(codigo);
        if (!funcionarioValido(funcionario) || produto == null ||
                quantidade <= 0 || quantidade > Integer.MAX_VALUE - produto.getQuantidade()) {
            return false;
        }

        produto.adicionarEstoque(quantidade);
        notificar(EventoSistema.ESTOQUE_REPOSTO, produto);
        return true;
    }

    public Pedido criarPedido(Cliente cliente) {
        if (cliente == null || !usuarios.contains(cliente)) {
            throw new IllegalArgumentException("Cliente nao cadastrado.");
        }

        Pedido pedido = new Pedido(proximoNumeroPedido, cliente);
        proximoNumeroPedido++;
        pedidosAbertos.add(pedido);
        return pedido;
    }

    public boolean adicionarItem(Pedido pedido, int codigo, int quantidade) {
        Produto produto = catalogo.buscarProduto(codigo);
        if (pedido == null || !pedidosAbertos.contains(pedido) ||
                produto == null || quantidade <= 0) {
            return false;
        }

        long total = quantidade;
        for (ItemPedido item : pedido.getItens()) {
            if (item.getProduto() == produto) {
                total += item.getQuantidade();
            }
        }

        if (total > produto.getQuantidade()) {
            return false;
        }

        pedido.adicionarItem(new ItemPedido(produto, quantidade));
        return true;
    }

    //atualiza o pedido a partir do carrinho da tela
    public Pedido atualizarPedidoDoCarrinho(Cliente cliente, Pedido pedidoAnterior, Map<Integer, Integer> carrinho) {
        if (cliente == null || !usuarios.contains(cliente) || carrinho == null) {
            throw new IllegalArgumentException("Dados invalidos para atualizar o pedido.");
        }

        if (pedidoAnterior != null &&
                (!pedidosAbertos.contains(pedidoAnterior) || pedidoAnterior.getCliente() != cliente)) {
            throw new IllegalArgumentException("Pedido anterior invalido.");
        }
        //verifica os produtos antes de modificar o pedido
        for (Map.Entry<Integer, Integer> item : carrinho.entrySet()) {
            Integer codigo = item.getKey();
            Integer quantidade = item.getValue();

            Produto produto = codigo == null ? null : catalogo.buscarProduto(codigo);

            if (produto == null || quantidade == null || quantidade <= 0 || quantidade > produto.getQuantidade()) {
                throw new IllegalArgumentException("Quantidade indisponivel para compra.");
            }
        }

        if (pedidoAnterior != null) {
            cancelarPedido(pedidoAnterior);
        }

        if (carrinho.isEmpty()) {
            return null;
        }

        Pedido novoPedido = criarPedido(cliente);

        for (Map.Entry<Integer, Integer> item : carrinho.entrySet()) {
            if (!adicionarItem(novoPedido, item.getKey(), item.getValue())) {
                cancelarPedido(novoPedido);
                throw new IllegalStateException("Nao foi possivel atualizar o pedido.");
            }
        }
        return novoPedido;
    }

    public boolean cancelarPedido(Pedido pedido) {
        return pedidosAbertos.remove(pedido);
    }

    public boolean finalizarPedido(Pedido pedido, String formaPagamento) {
        try {
            return finalizarPedido(pedido, new Pagamento(formaPagamento));
        } catch (IllegalArgumentException erro) {
            return false;
        }
    }

    public boolean finalizarPedido(Pedido pedido, Pagamento pagamento) {
        if (pedido == null || pagamento == null || !pedidosAbertos.contains(pedido) || pedido.getItens().isEmpty()) {
            return false;
        }

        // Confere todo o estoque antes de descontar qualquer produto.
        for (ItemPedido item : pedido.getItens()) {
            Produto produto = item.getProduto();
            if (catalogo.buscarProduto(produto.getCodigo()) != produto) {
                return false;
            }

            long totalDoProduto = 0;
            for (ItemPedido outro : pedido.getItens()) {
                if (outro.getProduto() == produto) {
                    totalDoProduto += outro.getQuantidade();
                }
            }

            if (totalDoProduto > produto.getQuantidade()) {
                return false;
            }
        }

        if (!pagamento.processarPagamento(pedido.calcularTotal())) {
            return false;
        }

        for (ItemPedido item : pedido.getItens()) {
            item.getProduto().retirarEstoque(item.getQuantidade());
        }

        pedido.finalizar(pagamento.getForma());
        pedidosAbertos.remove(pedido);
        pedidosFinalizados.add(pedido);
        pedido.getCliente().adicionarPedido(pedido);

        //avisa só depois de tudo atualizado
        notificar(EventoSistema.PEDIDO_FINALIZADO, pedido);
        LinkedHashSet<Produto> afetados = new LinkedHashSet<>();
        for (ItemPedido item : pedido.getItens()) {
            afetados.add(item.getProduto());
        }
        for (Produto produto : afetados) {
            if (produto.getQuantidade() <= LIMITE_ESTOQUE_BAIXO) {
                notificar(EventoSistema.ESTOQUE_BAIXO, produto);
            }
        }
        return true;
    }

    public ArrayList<Pedido> listarPedidos() {
        return new ArrayList<>(pedidosFinalizados);
    }

    public ArrayList<Pedido> listarPedidos(Cliente cliente) {
        if (cliente == null || !usuarios.contains(cliente)) {
            return new ArrayList<>();
        }
        return cliente.getPedidos();
    }

    public double calcularTotalVendas() {
        double total = 0;
        for (Pedido pedido : pedidosFinalizados) {
            total += pedido.calcularTotal();
        }
        return total;
    }

    private boolean funcionarioValido(Funcionario funcionario) {
        return funcionario != null && usuarios.contains(funcionario);
    }

    public ArrayList<Pedido> listarPedidos(Funcionario funcionario) {
        if (!funcionarioValido(funcionario)) {
            return new ArrayList<>();
        }
        return listarPedidos();
    }

    public String gerarRelatorioVendas() {
        StringBuilder relatorio = new StringBuilder("RELATORIO DE VENDAS\n");

        for (Pedido pedido : pedidosFinalizados) {
            relatorio.append("Pedido ").append(pedido.getNumero())
                     .append(" - Cliente: ").append(pedido.getCliente().getNome())
                     .append(" - Total: R$ ")
                     .append(String.format(Locale.forLanguageTag("pt-BR"),
                             "%.2f", pedido.calcularTotal()))
                     .append("\n");
        }
        relatorio.append("Pedidos finalizados: ").append(pedidosFinalizados.size());
        relatorio.append("\nValor vendido: R$ ")
                 .append(String.format(Locale.forLanguageTag("pt-BR"),
                         "%.2f", calcularTotalVendas()));
        return relatorio.toString();
    }
}
