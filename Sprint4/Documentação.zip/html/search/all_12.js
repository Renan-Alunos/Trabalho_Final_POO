var searchData=
[
  ['valortotal_0',['valorTotal',['../classTelaCliente.html#aeca2791246430fcea7e5f103d6a1462a',1,'TelaCliente']]],
  ['voltaraologin_1',['voltarAoLogin',['../classTelaFarmacia.html#a5cc81b6269df210f91a882252ef2cd12',1,'TelaFarmacia']]]
];
