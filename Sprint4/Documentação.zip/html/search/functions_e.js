var searchData=
[
  ['usuario_0',['Usuario',['../classUsuario.html#a78d2bb6138bf8ee4d79cd5efab0c68c8',1,'Usuario']]]
];
