var searchData=
[
  ['exigirpedido_0',['exigirPedido',['../classMain.html#ae1dc5d70c33fc4fb5fb9f39ab47542b5',1,'Main']]]
];
