var searchData=
[
  ['nome_0',['nome',['../classProduto.html#a4cfff30ec02286864b995e013b6c2a41',1,'Produto.nome'],['../classUsuario.html#a4cfff30ec02286864b995e013b6c2a41',1,'Usuario.nome']]],
  ['numero_1',['numero',['../classPedido.html#a2c30f43104974e72e2809fb4569804b0',1,'Pedido']]]
];
