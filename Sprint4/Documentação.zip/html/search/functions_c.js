var searchData=
[
  ['removerobservador_0',['removerObservador',['../classSistema.html#a276922bb2f53cdc26d7cdf772cefe447',1,'Sistema']]],
  ['reporestoque_1',['reporestoque',['../classTelaFuncionario.html#a747b6504814a2680fba42561ff043e47',1,'TelaFuncionario.reporEstoque()'],['../classTelaFuncionario.html#a747b6504814a2680fba42561ff043e47',1,'TelaFuncionario.reporEstoque()'],['../classSistema.html#aa8abb9d4299ab0e7255440341337c415',1,'Sistema.reporEstoque(Funcionario funcionario, int codigo, int quantidade)'],['../classSistema.html#aa8abb9d4299ab0e7255440341337c415',1,'Sistema.reporEstoque(Funcionario funcionario, int codigo, int quantidade)']]],
  ['retirarestoque_2',['retirarestoque',['../classProduto.html#a61c93d468d39b6fa765f8929a64fa078',1,'Produto.retirarEstoque(int quantidade)'],['../classProduto.html#a61c93d468d39b6fa765f8929a64fa078',1,'Produto.retirarEstoque(int quantidade)']]]
];
