var searchData=
[
  ['quantidade_0',['quantidade',['../classItemPedido.html#aab7e2f8a805bde3912f985c05be7d510',1,'ItemPedido.quantidade'],['../classProduto.html#aab7e2f8a805bde3912f985c05be7d510',1,'Produto.quantidade']]]
];
