var searchData=
[
  ['valortotal_0',['valorTotal',['../classTelaCliente.html#aeca2791246430fcea7e5f103d6a1462a',1,'TelaCliente']]],
  ['verificacoes_1',['verificacoes',['../classTesteSprint4.html#acbbd5ed9416e09b6e8a9cee63a164f1c',1,'TesteSprint4']]]
];
