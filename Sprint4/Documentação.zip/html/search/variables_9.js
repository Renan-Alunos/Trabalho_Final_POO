var searchData=
[
  ['resumocarrinho_0',['resumoCarrinho',['../classTelaCliente.html#a4cce0d0dcf38ee3f1b74cafdf6492699',1,'TelaCliente']]]
];
