var indexSectionsWithContent =
{
  0: "abcdefgilmnopqrstuv",
  1: "cfimpstu",
  2: "cfimpstu",
  3: "abcdefgilmprstuv",
  4: "acfimnopqrstuv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Estruturas de dados",
  2: "Arquivos",
  3: "Funções",
  4: "Variáveis"
};

