var searchData=
[
  ['voltaraologin_0',['voltaraologin',['../classTelaFarmacia.html#a5cc81b6269df210f91a882252ef2cd12',1,'TelaFarmacia.voltarAoLogin()'],['../classTelaFarmacia.html#a5cc81b6269df210f91a882252ef2cd12',1,'TelaFarmacia.voltarAoLogin()']]]
];
